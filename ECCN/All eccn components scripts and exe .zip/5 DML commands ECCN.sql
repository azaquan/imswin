begin transaction
update Po SET PO_USEXPORT = 0 

update pesys set psys_eccnactivate ='n' , psys_eccnlength=5

update poitem set poi_usexport =0 , poi_eccnlicsreq =0

insert into menuoption 
select mo_npecode, '01010106', 'Eccn',1,getdate(), 'IMSUSA',getdate(),'IMSUSA' from menuoption 
where mo_meopid = '01000000' and mo_npecode='pect'

insert into menuoption 
select mo_npecode, '01010107', 'Eccn Source',1,getdate(), 'IMSUSA',getdate(),'IMSUSA' from menuoption 
where mo_meopid = '01000000' and mo_npecode='pect'

insert into menuoption 
select mo_npecode, '03020101', 'Re-Order Report',1,getdate(), 'IMSUSA',getdate(),'IMSUSA' from menuoption 
where mo_meopid = '01000000' and mo_npecode='pect'


insert into menuoption 
select mo_npecode, '03020102', 'Requisition Status',1,getdate(), 'IMSUSA',getdate(),'IMSUSA' from menuoption 
where mo_meopid = '01000000' and mo_npecode='pect'


insert into menuuser select 'PECT','IMSUSA','01010106', 1,1,1,	1,	getdate(), 'IMSUSA',Getdate(),'IMSUSA'
insert into menuuser select 'PECT','IMSUSA','01010107', 1,1,1,	1,	getdate(), 'IMSUSA',Getdate(),'IMSUSA'

insert into menuuser select 'PECT','IMSUSA','03020101', 1,1,1,	1,	getdate(), 'IMSUSA',Getdate(),'IMSUSA'
insert into menuuser select 'PECT','IMSUSA','03020102', 1,1,1,	1,	getdate(), 'IMSUSA',Getdate(),'IMSUSA'

INSERT INTO MENUUSER
SELECT mu_npecode, mu_userid, '01010106',  1, 1, 1, mu_tbs, GETDATE(),
 'IMSUSA', GETDATE(), 'IMSUSA'  FROM MENUUSER WHERE MU_MEOPID ='02020100' AND MU_USERID <>'IMSUSA'

INSERT INTO MENUUSER
SELECT mu_npecode, mu_userid, '01010107',  1, 1, 1, mu_tbs, GETDATE(),
 'IMSUSA', GETDATE(), 'IMSUSA'  FROM MENUUSER WHERE MU_MEOPID ='02020100' AND MU_USERID <>'IMSUSA'

INSERT INTO MENUUSER
SELECT mu_npecode, mu_userid, '03020101',  1, 1, 1, mu_tbs, GETDATE(),
 'IMSUSA', GETDATE(), 'IMSUSA'  FROM MENUUSER WHERE MU_MEOPID ='02020100' AND MU_USERID <>'IMSUSA'

INSERT INTO MENUUSER
SELECT mu_npecode, mu_userid, '03020102',  1, 1, 1, mu_tbs, GETDATE(),
 'IMSUSA', GETDATE(), 'IMSUSA'  FROM MENUUSER WHERE MU_MEOPID ='02020100' AND MU_USERID <>'IMSUSA'


INSERT INTO MENUACCESS
SELECT ma_npecode, ma_melvid, '01010106',  1, 1, 1, ma_tbs, GETDATE(),
'IMSUSA', GETDATE(), 'IMSUSA' 
FROM MENUACCESS WHERE MA_MEOPID IN ('02020100')

INSERT INTO MENUACCESS
SELECT ma_npecode, ma_melvid, '01010107',  1, 1, 1, ma_tbs, GETDATE(),
'IMSUSA', GETDATE(), 'IMSUSA' 
FROM MENUACCESS WHERE MA_MEOPID IN ('02020100')


INSERT INTO MENUACCESS
SELECT ma_npecode, ma_melvid, '03020101',  1, 1, 1, ma_tbs, GETDATE(),
'IMSUSA', GETDATE(), 'IMSUSA' 
FROM MENUACCESS WHERE MA_MEOPID IN ('02020100')

INSERT INTO MENUACCESS
SELECT ma_npecode, ma_melvid, '03020102',  1, 1, 1, ma_tbs, GETDATE(),
'IMSUSA', GETDATE(), 'IMSUSA' 
FROM MENUACCESS WHERE MA_MEOPID IN ('02020100')


insert into [Schema]
(VBFORM, DBTableName, DBPrimaryKey1, DBPrimaryKey2, DBPrimaryKey3, DBPrimaryKey4, DBPrimaryKey5, DBPrimaryKey6 , DBPrimaryKey7, VBPrimaryKey1, VBPrimaryKey2, VBPrimaryKey3, VBPrimaryKey4 ,  VBPrimaryKey5 ,  VBPrimaryKey6, VBPrimaryKey7)
 select 	'frmeccn',	'ECCN',	'eccnid',null, null, null, null, null, null, 'ssoleeccn',null, null, null, null, null, null
insert into [Schema]
(VBFORM, DBTableName, DBPrimaryKey1, DBPrimaryKey2, DBPrimaryKey3, DBPrimaryKey4, DBPrimaryKey5, DBPrimaryKey6 , DBPrimaryKey7, VBPrimaryKey1, VBPrimaryKey2, VBPrimaryKey3, VBPrimaryKey4 ,  VBPrimaryKey5 ,  VBPrimaryKey6, VBPrimaryKey7)
 select 	'frmpicklist',	'PICKLIST',	'sourceid',null, null, null, null, null, null,'ssoleeccn',null, null, null, null, null, null








