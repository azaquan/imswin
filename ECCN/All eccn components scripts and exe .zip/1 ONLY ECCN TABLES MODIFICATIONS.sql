if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PICKLIST]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[PICKLIST]
GO

CREATE TABLE [dbo].[PICKLIST] (
	[sourceid] [int] IDENTITY (1, 1) NOT NULL ,
	[npecode] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[source] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[source_desc] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[source_active] [bit] NULL ,
	[source_creauser] [CREATEUSER] NULL ,
	[source_creadate] [CREATEDATE] NULL ,
	[source_modiuser] [CREATEUSER] NULL ,
	[source_modidate] [CREATEDATE] NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[PICKLIST] WITH NOCHECK ADD 
	CONSTRAINT [PK_PICKLIST] PRIMARY KEY  CLUSTERED 
	(
		[sourceid]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[PICKLIST] ADD 
	CONSTRAINT [DF_PICKLIST_eccn_active] DEFAULT (1) FOR [source_active],
	CONSTRAINT [IX_PICKLIST] UNIQUE  NONCLUSTERED 
	(
		[npecode],
		[source]
	)  ON [PRIMARY] 
GO

setuser
GO

EXEC sp_bindefault N'[dbo].[CREATEDATEDEF]', N'[PICKLIST].[source_creadate]'
GO

EXEC sp_bindrule N'[dbo].[No_Empty_String]', N'[PICKLIST].[source_creauser]'
GO

EXEC sp_bindefault N'[dbo].[CREATEUSERDEF]', N'[PICKLIST].[source_creauser]'
GO

EXEC sp_bindefault N'[dbo].[CREATEDATEDEF]', N'[PICKLIST].[source_modidate]'
GO

EXEC sp_bindrule N'[dbo].[No_Empty_String]', N'[PICKLIST].[source_modiuser]'
GO

EXEC sp_bindefault N'[dbo].[CREATEUSERDEF]', N'[PICKLIST].[source_modiuser]'
GO

setuser
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ECCN]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ECCN]
GO

CREATE TABLE [dbo].[ECCN] (
	[eccnid] [bigint] IDENTITY (1, 1) NOT NULL ,
	[eccn_npecode] [NPECODE] NOT NULL ,
	[eccn_no] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[eccn_desc] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[eccn_active] [bit] NOT NULL ,
	[eccn_creauser] [CREATEUSER] NULL ,
	[eccn_creadate] [CREATEDATE] NULL ,
	[eccn_modiuser] [CREATEUSER] NULL ,
	[eccn_modidate] [CREATEDATE] NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ECCN] WITH NOCHECK ADD 
	CONSTRAINT [PK_ECCN] PRIMARY KEY  CLUSTERED 
	(
		[eccnid]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ECCN] ADD 
	CONSTRAINT [DF_ECCN_eccn_active] DEFAULT (1) FOR [eccn_active],
	CONSTRAINT [IX_ECCN] UNIQUE  NONCLUSTERED 
	(
		[eccn_npecode],
		[eccn_no]
	)  ON [PRIMARY] 
GO

setuser
GO

EXEC sp_bindefault N'[dbo].[CREATEDATEDEF]', N'[ECCN].[eccn_creadate]'
GO

EXEC sp_bindrule N'[dbo].[No_Empty_String]', N'[ECCN].[eccn_creauser]'
GO

EXEC sp_bindefault N'[dbo].[CREATEUSERDEF]', N'[ECCN].[eccn_creauser]'
GO

EXEC sp_bindefault N'[dbo].[CREATEDATEDEF]', N'[ECCN].[eccn_modidate]'
GO

EXEC sp_bindrule N'[dbo].[No_Empty_String]', N'[ECCN].[eccn_modiuser]'
GO

EXEC sp_bindefault N'[dbo].[CREATEUSERDEF]', N'[ECCN].[eccn_modiuser]'
GO

EXEC sp_bindrule N'[dbo].[No_Empty_String]', N'[ECCN].[eccn_npecode]'
GO

setuser
GO


ALTER TABLE STOCKMASTER
	ADD  	
		[stk_eccnid] [bigint] NULL ,
	  	[stk_eccnlicsreq] [bit] NULL ,	
	  	[stk_eccnsourceid] [int] NULL 
GO
/*
ALTER TABLE [dbo].[STOCKMASTER] ADD 
	CONSTRAINT [FK_STOCKMASTER_ECCN] FOREIGN KEY 
	(
		[stk_eccnid]
	) REFERENCES [dbo].[ECCN] (
		[eccnid]
	) NOT FOR REPLICATION ,
	CONSTRAINT [FK_STOCKMASTER_PICKLIST] FOREIGN KEY 
	(
		[stk_eccnsourceid]
	) REFERENCES [dbo].[PICKLIST] (
		[sourceid]
	) NOT FOR REPLICATION 
GO
*/
--------------------------------------------------------------------------------
--PO

ALTER TABLE PO
	ADD  [po_usexport] [bit] NULL 
	
GO
ALTER TABLE [dbo].[PO] ADD 
	CONSTRAINT [DF_PO_USEXPORT] DEFAULT (0) FOR [po_usexport]
GO

ALTER TABLE POITEM
	ADD  	[poi_eccnid] [bigint] NULL ,
	 	[poi_sourceid] [int] NULL ,
	  	[poi_eccnlicsreq] [bit] NULL ,
	  	[poi_usexport] [bit] NULL 

ALTER TABLE [dbo].[POITEM] ADD 
	CONSTRAINT [DF_POITEM_USEXPORT] DEFAULT (0) FOR [poI_usexport]
GO

/*
ALTER TABLE [dbo].[POITEM] ADD 
	CONSTRAINT [FK_POITEM_ECCN] FOREIGN KEY 
	(
		[poi_eccnid]
	) REFERENCES [dbo].[ECCN] (
		[eccnid]
	) NOT FOR REPLICATION ,
	CONSTRAINT [FK_POITEM_PICKLIST] FOREIGN KEY 
	(
		[poi_sourceid]
	) REFERENCES [dbo].[PICKLIST] (
		[sourceid]
	) NOT FOR REPLICATION 
GO

*/

--------------------------------------------------------------------------------------------
--PESYS
ALTER TABLE PESYS
	ADD  [psys_eccnactivate] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	  [psys_usexport] [bit] NULL ,
	  [psys_eccnlength] [int] NULL
go

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER ECCNActivate ON [dbo].[PESYS] 
FOR INSERT, UPDATE
AS
Declare @eccnactivate char(1)
Declare @namespace npecode
Declare @psys_usexport bit
if update(psys_eccnactivate) 
begin

	SELECT @eccnactivate = psys_eccnactivate, @namespace= psys_npecode FROM INSERTED
	if @eccnactivate = 'y' or  @eccnactivate = 'o'
	begin	
		update pesys set  psys_usexport =1 where psys_npecode = @namespace
	end

	if @eccnactivate = 'n' 
	begin	
		update pesys set  psys_usexport =0 where psys_npecode = @namespace
	end

end 


if update(psys_usexport) 
begin

	SELECT @eccnactivate =psys_eccnactivate, @psys_usexport=  psys_usexport, @namespace= psys_npecode FROM INSERTED
	if @eccnactivate = 'y' and @psys_usexport =0 
	begin	
		update pesys set  psys_usexport =1 where psys_npecode = @namespace
	end

	else if @eccnactivate = 'n' and @psys_usexport =1
	begin
		update pesys set  psys_usexport =0 where psys_npecode = @namespace
	end
end 




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
