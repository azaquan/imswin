
insert into reports 
select 'requisitionstatus.rpt' , 'subReception.rpt', 'pecten.dbo.reception'
insert into reports 
select 'requisitionstatus.rpt' , 'subReception.rpt', 'pecten.dbo.ReceiptionDetl'

insert into reports 
select 'requisitionstatus.rpt' , 'subPacking.rpt', 'pecten.dbo.packingdetl'
insert into reports 
select 'requisitionstatus.rpt' , 'subPacking.rpt', 'pecten.dbo.packinglist'

insert into reports 
select 'requisitionstatus.rpt' , 'subInventoryrcpt.rpt', 'pecten.dbo.invtreceipt'
insert into reports 
select 'requisitionstatus.rpt' , 'subInventoryrcpt.rpt', 'pecten.dbo.invtreceiptdetl'