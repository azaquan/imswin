select * from stockmaster where isnumeric(stk_mini) =0 or isnumeric(stk_maxi) =0
--delete from stockmaster where isnumeric(stk_mini) =0 and isnumeric(stk_maxi) =0
begin tran
update stockmaster set stk_mini =
case
	when s2.stk_mini is null then cast(0 as char(6))
	when len(s2.stk_mini)=0 then cast(0 as char(6))
	when isnumeric(s2.stk_mini)=0 then cast(0 as char(6))
	else s2.stk_mini
end
,
stk_maxi =
case
	when s2.stk_maxi is null then cast(0 as char(6))
	when len(s2.stk_maxi)=0 then cast(0 as char(6))
	when isnumeric(s2.stk_maxi)=0 then cast(0 as char(6))
	else s2.stk_maxi
end
from stockmaster s2
where s2.stk_stcknumb =stk_stcknumb and s2.stk_npecode = stk_npecode
and isnumeric(stk_mini) =0 or  isnumeric(stk_maxi) =0
rollback
commit transaction